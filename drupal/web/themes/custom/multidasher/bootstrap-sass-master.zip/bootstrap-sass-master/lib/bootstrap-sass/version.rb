module Bootstrap
  VERSION       = '3.3.7'
  BOOTSTRAP_SHA = '0b9c4a4007c44201dce9a6cc1a38407005c26c86'
end
